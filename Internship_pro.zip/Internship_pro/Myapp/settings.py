 # LinkedIn OAuth Configuration
LINKEDIN_CLIENT_ID = "86ym363ssaf6tz"  # Replace with actual client ID
LINKEDIN_CLIENT_SECRET = "WPL_AP1.P9uxAiGWy4DjSRYh.WIbjkw=="  # Replace with actual client secret
LINKEDIN_REDIRECT_URI = "http://127.0.0.1:8000/Myapp/linkedin-callback"
DEFAULT_REDIRECT_URL = "http://localhost:8080/register"  # Default redirect URL after LinkedIn auth